# Estadistica descriptiva e inferencial sobre los datos de COVID-19

Fuente de los datos:
1. https://datos.gob.mx/busca/dataset/informacion-referente-a-casos-covid-19-en-mexico8  (Consultado el 27/05/2020)

Falta una descripción, pero no se si lo quieran hacer publico jajajaja depende de cómo quede